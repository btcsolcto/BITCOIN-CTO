# Bitcoin CTO | BTC

**Official GitHub Repository for the Bitcoin CTO Ecosystem**  
Website: [https://btcsolcto.com](https://btcsolcto.com)

---

## Overview

Bitcoin CTO | BTC is a fully community-driven decentralized project. We’re building a powerful ecosystem combining a native token (BTC) on Solana and a collectible NFT series called **Chainlords**, with on-chain lore, verified ERC-721 contracts, and Web3 utility.

---

## Features

- **Token Name:** Bitcoin CTO  
- **Ticker:** BTC  
- **Total Supply:** 1,000,000,000  
- **Chain:** Solana  
- **CA:** `E1SRZt1qm7rFGNPVHixNyYzTt7Ha44uyU6n7tFdEpump`  
- **Website:** [btcsolcto.com](https://btcsolcto.com)  
- **NFT Vault:** [Chainlords Collection](https://btcsolcto.com/official-chainlords-vault)

---

## Smart Contracts

All contracts are written in Solidity (for NFTs) and deployed via Remix.

- `BTCSOLCTO.sol`: Governance & utility token on Solana  
- `ChainlordsUR.sol`: Custom ERC-721 for Ultra Rare NFTs with royalty and airdrop support  

You can find verified contract sources inside the `/contracts` directory.

---

## NFT Metadata

Each Chainlord NFT includes:
- Title, Lore, Artwork
- Standard ERC-721 Metadata JSON
- Hosted on IPFS or Arweave
- Viewable on Magic Eden & OpenSea

Explore metadata in `/metadata/NFTs`.

---

## Community & Support

- Telegram: [https://t.me/Bitcoinbtcsolcto](https://t.me/Bitcoinbtcsolcto)  
- X (Twitter): [https://x.com/btcsolcto](https://x.com/btcsolcto)  
- Email: [support@btcsolcto.com](mailto:support@btcsolcto.com)

---

## Legal & Terms

- [Privacy Policy](docs/PrivacyPolicy.html)
- [NFT Terms & Asset Management Agreement](docs/NFT_Terms_AssetAgreement.html)

---

## License

This repository and its contents are licensed under the MIT License unless otherwise stated.  
Please refer to `LICENSE` for more information.

---

## Credits

All artworks, Chainlords lore, and digital assets are original creations by the Bitcoin CTO team.  
Unauthorized reproduction or distribution is prohibited.

© 2025 Bitcoin CTO. All rights reserved.
